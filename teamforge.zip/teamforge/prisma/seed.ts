import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const HACKATHON_SKILLS = ["Frontend", "Backend", "AI/ML", "UI/UX", "DevOps", "Product/Pitch"];
const CTF_SKILLS = ["Web Exploitation", "Pwn", "Reverse Engineering", "Cryptography", "OSINT", "Forensics"];

async function main() {
  for (const name of HACKATHON_SKILLS) {
    await prisma.skill.upsert({
      where: { name },
      update: {},
      create: { name, category: "hackathon" },
    });
  }
  for (const name of CTF_SKILLS) {
    await prisma.skill.upsert({
      where: { name },
      update: {},
      create: { name, category: "ctf" },
    });
  }
  console.log("Seeded skill taxonomy.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
