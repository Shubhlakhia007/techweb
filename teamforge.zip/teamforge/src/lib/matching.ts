// Core gap-matching and eligibility logic for TeamForge.
// Kept as plain, framework-free functions so they're easy to read, test, and
// reuse from any API route. No AI/external calls anywhere in here — v1 is
// entirely rule-based.

export type SkillRequirement = { skillId: string; minCount: number };

export type CandidateSkill = { skillId: string; proficiency: number };

export type Candidate = {
  userId: string;
  skills: CandidateSkill[];
  location?: string | null;
  travelRadiusKm?: number | null;
  timezone?: string | null;
  eventPreference?: string | null; // "online" | "offline" | "either"
};

export type TeamMemberSkills = { userId: string; skills: CandidateSkill[] };

/**
 * Counts how many current team members have each required skill.
 */
export function computeTeamSkillCoverage(
  members: TeamMemberSkills[],
  requiredSkills: SkillRequirement[]
): Record<string, number> {
  const coverage: Record<string, number> = {};
  for (const req of requiredSkills) {
    coverage[req.skillId] = members.filter((m) =>
      m.skills.some((s) => s.skillId === req.skillId)
    ).length;
  }
  return coverage;
}

/**
 * The gap vector: for each required skill, how many more people the team
 * still needs who have it. Never negative.
 */
export function computeGapVector(
  requiredSkills: SkillRequirement[],
  coverage: Record<string, number>
): Record<string, number> {
  const gap: Record<string, number> = {};
  for (const req of requiredSkills) {
    gap[req.skillId] = Math.max(req.minCount - (coverage[req.skillId] ?? 0), 0);
  }
  return gap;
}

/**
 * Scores a single candidate by how much of the current gap they would close,
 * weighted by their proficiency in each gap skill (1-5).
 */
export function scoreCandidate(candidate: Candidate, gap: Record<string, number>): number {
  let score = 0;
  for (const skillId of Object.keys(gap)) {
    if (gap[skillId] <= 0) continue;
    const match = candidate.skills.find((s) => s.skillId === skillId);
    if (match) score += match.proficiency;
  }
  return score;
}

/**
 * Ranks candidates highest-score-first, dropping anyone who scores 0
 * (i.e. contributes nothing to the team's current gap).
 */
export function rankCandidates(
  candidates: Candidate[],
  gap: Record<string, number>
): Array<{ candidate: Candidate; score: number }> {
  return candidates
    .map((candidate) => ({ candidate, score: scoreCandidate(candidate, gap) }))
    .filter((c) => c.score > 0)
    .sort((a, b) => b.score - a.score);
}

export type Event = {
  mode: string; // "online" | "offline"
  teamSizeMin: number;
  teamSizeMax: number;
  diversityRuleText?: string | null;
};

export type EligibilityResult = {
  eligible: boolean;
  reasons: string[]; // failure reasons if eligible === false; manual-check notes otherwise
};

/**
 * Hard pass/fail eligibility check — independent of skill scoring.
 * A candidate/team can score well and still fail this.
 */
export function checkTeamEligibility(currentMemberCount: number, event: Event): EligibilityResult {
  const reasons: string[] = [];

  if (currentMemberCount < event.teamSizeMin) {
    reasons.push(`Team has ${currentMemberCount} members, needs at least ${event.teamSizeMin}.`);
  }
  if (currentMemberCount > event.teamSizeMax) {
    reasons.push(`Team has ${currentMemberCount} members, exceeds the max of ${event.teamSizeMax}.`);
  }
  if (event.diversityRuleText) {
    reasons.push(`Manual check needed: "${event.diversityRuleText}"`);
  }

  // Only size violations make the team ineligible; diversity rule is
  // surfaced as a manual checklist item in v1, not auto-enforced.
  const eligible = currentMemberCount >= event.teamSizeMin && currentMemberCount <= event.teamSizeMax;

  return { eligible, reasons };
}

/**
 * Filters out candidates who can't join this event/team for location or
 * timezone reasons. Applied BEFORE scoring so ineligible people never show
 * up in the ranked list.
 */
export function filterEligibleCandidates(candidates: Candidate[], event: Event): Candidate[] {
  return candidates.filter((c) => {
    if (event.mode === "offline") {
      // v1: simple presence check. Real distance calc can be added once
      // event/candidate lat-lng are captured.
      return c.eventPreference !== "online";
    }
    if (event.mode === "online") {
      return c.eventPreference !== "offline";
    }
    return true;
  });
}
