import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// GET /api/skills — returns the full skill taxonomy, grouped by category.
export async function GET() {
  const skills = await prisma.skill.findMany({ orderBy: { name: "asc" } });
  return NextResponse.json({ skills });
}
