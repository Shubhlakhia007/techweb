import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  computeTeamSkillCoverage,
  computeGapVector,
  rankCandidates,
  filterEligibleCandidates,
  type Candidate,
} from "@/lib/matching";

// GET /api/teams/:teamId/recommendations — ranked candidates who best close
// this team's current skill gap for its event, filtered to eligible people only.
export async function GET(_request: Request, { params }: { params: { teamId: string } }) {
  const team = await prisma.team.findUnique({
    where: { id: params.teamId },
    include: {
      members: { include: { user: { include: { skills: true } } } },
      event: { include: { requiredSkills: true } },
    },
  });

  if (!team) return NextResponse.json({ error: "Team not found" }, { status: 404 });

  const memberIds = team.members.map((m) => m.userId);

  const coverage = computeTeamSkillCoverage(
    team.members.map((m) => ({
      userId: m.userId,
      skills: m.user.skills.map((s) => ({ skillId: s.skillId, proficiency: s.proficiency })),
    })),
    team.event.requiredSkills.map((r) => ({ skillId: r.skillId, minCount: r.minCount }))
  );

  const gap = computeGapVector(
    team.event.requiredSkills.map((r) => ({ skillId: r.skillId, minCount: r.minCount })),
    coverage
  );

  // Candidate pool: everyone except current team members.
  const pool = await prisma.user.findMany({
    where: { id: { notIn: memberIds } },
    include: { skills: true },
  });

  const candidates: Candidate[] = pool.map((u) => ({
    userId: u.id,
    skills: u.skills.map((s) => ({ skillId: s.skillId, proficiency: s.proficiency })),
    location: u.location,
    travelRadiusKm: u.travelRadiusKm,
    timezone: u.timezone,
    eventPreference: u.eventPreference,
  }));

  const eligiblePool = filterEligibleCandidates(candidates, team.event);
  const ranked = rankCandidates(eligiblePool, gap);

  return NextResponse.json({
    gap,
    recommendations: ranked.slice(0, 10),
  });
}
