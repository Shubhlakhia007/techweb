import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { checkTeamEligibility } from "@/lib/matching";

// GET /api/teams/:teamId/eligibility — checks this team against its event's rules.
export async function GET(_request: Request, { params }: { params: { teamId: string } }) {
  const team = await prisma.team.findUnique({
    where: { id: params.teamId },
    include: { members: true, event: true },
  });

  if (!team) return NextResponse.json({ error: "Team not found" }, { status: 404 });

  const result = checkTeamEligibility(team.members.length, team.event);

  return NextResponse.json(result);
}
