import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

// GET /api/events?type=hackathon&mode=online — list events with optional filters.
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const type = searchParams.get("type") ?? undefined;
  const mode = searchParams.get("mode") ?? undefined;

  const events = await prisma.event.findMany({
    where: { ...(type && { type }), ...(mode && { mode }) },
    include: { requiredSkills: { include: { skill: true } } },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ events });
}

// POST /api/events — create an event with its required-skill rows.
// body: { name, type, mode, teamSizeMin, teamSizeMax, diversityRuleText?,
//         requiredSkills: [{ skillId, minCount }] }
export async function POST(request: Request) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as { id?: string } | undefined)?.id;
  if (!userId) return NextResponse.json({ error: "Not signed in" }, { status: 401 });

  const body = await request.json();

  const event = await prisma.event.create({
    data: {
      name: body.name,
      type: body.type,
      mode: body.mode,
      teamSizeMin: body.teamSizeMin ?? 1,
      teamSizeMax: body.teamSizeMax ?? 6,
      diversityRuleText: body.diversityRuleText ?? null,
      createdById: userId,
      requiredSkills: {
        create: (body.requiredSkills ?? []).map((r: { skillId: string; minCount: number }) => ({
          skillId: r.skillId,
          minCount: r.minCount,
        })),
      },
    },
    include: { requiredSkills: true },
  });

  return NextResponse.json({ event }, { status: 201 });
}
