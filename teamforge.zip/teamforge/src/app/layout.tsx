import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "TeamForge",
  description: "Find the teammate your team is actually missing.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-50 text-slate-900">{children}</body>
    </html>
  );
}
