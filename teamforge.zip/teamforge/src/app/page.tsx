import Link from "next/link";

export default function HomePage() {
  return (
    <main className="mx-auto flex max-w-2xl flex-col items-center gap-6 px-4 py-24 text-center">
      <h1 className="text-4xl font-bold text-slate-900">TeamForge</h1>
      <p className="text-lg text-slate-600">
        Find the teammate your team is actually missing — not just anyone with a skill.
      </p>
      <div className="flex gap-3">
        <Link
          href="/events"
          className="rounded-md bg-slate-900 px-5 py-2.5 text-white hover:bg-slate-700"
        >
          Browse events
        </Link>
        <Link
          href="/api/auth/signin"
          className="rounded-md border border-slate-300 px-5 py-2.5 text-slate-900 hover:bg-slate-100"
        >
          Sign in
        </Link>
      </div>
    </main>
  );
}
