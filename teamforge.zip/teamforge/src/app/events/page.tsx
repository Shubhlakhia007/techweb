import { prisma } from "@/lib/prisma";

export default async function EventsPage() {
  const events = await prisma.event.findMany({
    include: { requiredSkills: { include: { skill: true } } },
    orderBy: { createdAt: "desc" },
  });

  return (
    <main className="mx-auto max-w-3xl px-4 py-12">
      <h1 className="mb-6 text-2xl font-bold">Events</h1>

      {events.length === 0 && (
        <p className="text-slate-500">No events yet — create one to get started.</p>
      )}

      <ul className="flex flex-col gap-4">
        {events.map((event) => (
          <li key={event.id} className="rounded-lg border border-slate-200 bg-white p-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">{event.name}</h2>
              <span className="rounded-full bg-slate-100 px-3 py-1 text-xs uppercase text-slate-600">
                {event.type} · {event.mode}
              </span>
            </div>
            <p className="mt-1 text-sm text-slate-500">
              Team size: {event.teamSizeMin}–{event.teamSizeMax}
            </p>
            <div className="mt-2 flex flex-wrap gap-2">
              {event.requiredSkills.map((r) => (
                <span key={r.skillId} className="rounded bg-slate-50 px-2 py-1 text-xs text-slate-600">
                  {r.skill.name} × {r.minCount}
                </span>
              ))}
            </div>
          </li>
        ))}
      </ul>
    </main>
  );
}
