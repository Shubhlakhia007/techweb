# TeamForge — v1 skeleton

Essential files only — no filler boilerplate. This is meant to be opened directly
in Antigravity (or any editor) and extended following `PROJECT_PLAN.md`.

## What's here

```
prisma/schema.prisma          Data model (Users, Skills, Events, Teams)
prisma/seed.ts                Seeds the skill taxonomy (hackathon + CTF categories)
src/lib/prisma.ts             Shared Prisma client
src/lib/auth.ts               NextAuth config (GitHub login)
src/lib/matching.ts           The core engine: gap-matching + eligibility logic (pure functions)
src/app/page.tsx              Landing page
src/app/events/page.tsx       Events list page
src/app/api/skills/route.ts           GET skill taxonomy
src/app/api/events/route.ts           GET/POST events
src/app/api/teams/[teamId]/recommendations/route.ts   Core matching, wired to real data
src/app/api/teams/[teamId]/eligibility/route.ts        Eligibility check
```

Deliberately NOT included yet (build these next, per PROJECT_PLAN.md phases 3-7):
`/onboarding` profile builder, `/events/new` create-event form, join-team flow,
team dashboard UI. The plumbing (schema + API + matching logic) comes first so
the UI has something real to call.

## First-time setup

1. **Install dependencies**
   ```
   npm install
   ```

2. **Create a free Neon Postgres database** at neon.tech, copy the connection
   string into `.env` (copy `.env.example` to `.env` first).

3. **Create a GitHub OAuth app** at github.com/settings/developers
   (callback URL: `http://localhost:3000/api/auth/callback/github`) and put
   the client ID/secret into `.env`. Generate `NEXTAUTH_SECRET` with:
   ```
   openssl rand -base64 32
   ```

4. **Push the schema and seed the skill taxonomy**
   ```
   npx prisma migrate dev --name init
   npm run prisma:seed
   ```

5. **Run it**
   ```
   npm run dev
   ```
   Visit `http://localhost:3000`.

## Deploying

Push to GitHub, import the repo into Vercel (Hobby plan), add the same
environment variables from `.env` in the Vercel project settings, and it
deploys automatically on every push to `main`.
